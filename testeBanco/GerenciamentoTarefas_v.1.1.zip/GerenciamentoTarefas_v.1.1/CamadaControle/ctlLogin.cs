﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CamadaModelo;
using System.Data;
using System.Data.OleDb;
using System.Configuration;
using System.Runtime;
using System.Web;

namespace CamadaControle
{
    public class ctlLogin
    {
        public static bool Login(CamadaModelo.mdlLogin _mdlLogin)
        {
            try
            {
                string conexaoAccess = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Fabio\Documents\VisualStudio2013\Projects\db\dbSistema.accdb";
                System.Data.OleDb.OleDbConnection conexaodb = new System.Data.OleDb.OleDbConnection(conexaoAccess);
                conexaodb.Open();

                string query = "INSERT INTO tbl_login(CPFLogin, SenhaLogin)VALUES('@Cpf', '@Senha')";
                System.Data.OleDb.OleDbCommand cmd = new System.Data.OleDb.OleDbCommand(query, conexaodb);

                var pmtCpf = cmd.CreateParameter();
                pmtCpf.ParameterName = "@Cpf";
                pmtCpf.DbType = DbType.String;
                pmtCpf.Value = _mdlLogin.Cpf;
                cmd.Parameters.Add(pmtCpf);

                var pmtSenha = cmd.CreateParameter();
                pmtSenha.ParameterName = "@Senha";
                pmtSenha.DbType = DbType.String;
                pmtSenha.Value = _mdlLogin.Senha;
                cmd.Parameters.Add(pmtSenha);

                

                if (cmd.ExecuteNonQuery() > 0)//executar o insert na base,se for maior que 0 ele vai fechar a conexao e retornar true
                {
                    conexaodb.Close();
                    return true;// esse return foi colocado true porque na assinatura esta bool
                }

                else
                {
                    conexaodb.Close();
                    return false;// esse return foi colocado false porque na assinatura esta bool
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
            finally
            {

                //conexaodb.Close();

            }
        }
    }
}
