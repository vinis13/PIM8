﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CamadaModelo
{
    public class mdlLogin
    {
        public int Codigo { get; set; }
        public string Cpf { get; set; }
        public string Senha { get; set; }
    }
}
