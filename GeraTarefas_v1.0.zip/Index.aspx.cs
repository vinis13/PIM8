﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using CamadaModelo;
using CamadaControle;
using System.Runtime;
using System.Data;
using System.Data.OleDb;

namespace $safeprojectname$
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            mdlLogin _mdlLogin = new mdlLogin();
            ctlLogin _ctlLogin = new ctlLogin();

            _mdlLogin.Cpf = txtUser.Text;
            _mdlLogin.Senha = txtSenha.Text;

            bool retornoInsert = ctlLogin.Login(_mdlLogin);

            if (retornoInsert == true)
            {
                ScriptManager.RegisterStartupScript(this, 
                                                    this.GetType(),
                                                    "sucesso",
                                                    "alert('Dados gravados com sucesso!')",
                                                    true);
            }
            
        }

        protected void Unnamed2_PageIndexChanging(object sender, FormViewPageEventArgs e)
        {

        }
    }
}